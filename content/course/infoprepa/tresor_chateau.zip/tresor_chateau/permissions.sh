MY_PATH="`dirname \"$0\"`"
chmod u-rx $MY_PATH/village/chateau/porte1;
chmod u-rx $MY_PATH/village/chateau/porte2;
chmod u-rx $MY_PATH/village/chateau/porte3;
chmod u-rx $MY_PATH/village/chateau/porte4/*;
chmod u-rx $MY_PATH/village/chateau/porte4;
chmod u-rx $MY_PATH/village/chateau/;

